# include "../include/Menu.h"
# include <iostream>

int main(){
    Menu menu;
    menu.principal_menu();
    return 0;
}
